"""Token usage sensors for DeepSeek Conversation.

Entity IDs use English suggested_object_id (language-neutral); display names
come from translations (entity.sensor.* in translations/*.json).
"""

from __future__ import annotations

from homeassistant.components.sensor import (  # pyright: ignore[reportMissingImports]
    RestoreSensor,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.core import HomeAssistant  # pyright: ignore[reportMissingImports]
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback  # pyright: ignore[reportMissingImports]

from .types import DeepSeekConfigEntry, usage_device_info
from .usage_metrics import CompletionUsage, UsageTracker


def _write_state_if_added(entity: SensorEntity) -> None:
    """Write entity state, unless Home Assistant has not added it yet.

    ``UsageTracker`` binds these sensors during platform setup, which runs
    before ``async_add_entities`` has registered them. An API call landing in
    that window - an automation firing ``ai_task.generate_data`` while the entry
    is still starting - would otherwise raise out of ``async_write_ha_state``
    and fail the request. The value is kept either way and reaches the state
    machine with the next update.
    """
    if entity.hass is None:
        return
    entity.async_write_ha_state()


class DeepSeekUsageCounterSensor(RestoreSensor, SensorEntity):
    """Cumulative counter (persists across restarts)."""

    _attr_has_entity_name = True
    _attr_state_class = SensorStateClass.TOTAL_INCREASING

    def __init__(
        self,
        entry: DeepSeekConfigEntry,
        translation_key: str,
        unique_suffix: str,
        *,
        unit: str,
        icon: str,
    ) -> None:
        self._entry = entry
        self._attr_translation_key = translation_key
        self._attr_unique_id = f"{entry.entry_id}_{unique_suffix}"
        self._attr_suggested_object_id = unique_suffix
        self._attr_native_unit_of_measurement = unit
        self._attr_icon = icon
        self._attr_device_info = usage_device_info(entry)

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = int(float(last_state.state))
            except (TypeError, ValueError):
                self._attr_native_value = 0
        elif self.native_value is None:
            self._attr_native_value = 0

    def increment(self, amount: int) -> None:
        if amount <= 0:
            return
        self._attr_native_value = int(self.native_value or 0) + amount
        _write_state_if_added(self)

    def reset_to_zero(self) -> None:
        self._attr_native_value = 0
        _write_state_if_added(self)


class DeepSeekSnapshotSensor(SensorEntity):
    """Value from the most recent API call (not restored across restarts)."""

    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "tokens"
    _attr_icon = "mdi:history"

    def __init__(
        self,
        entry: DeepSeekConfigEntry,
        translation_key: str,
        unique_suffix: str,
    ) -> None:
        self._entry = entry
        self._attr_translation_key = translation_key
        self._attr_unique_id = f"{entry.entry_id}_{unique_suffix}"
        self._attr_suggested_object_id = unique_suffix
        self._attr_device_info = usage_device_info(entry)
        self._attr_native_value = 0

    def set_value(self, value: int) -> None:
        self._attr_native_value = value
        _write_state_if_added(self)

    def reset_to_zero(self) -> None:
        self._attr_native_value = 0
        _write_state_if_added(self)


class DeepSeekLastRequestSensor(SensorEntity):
    """Tokens used by the most recent API call."""

    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "tokens"
    _attr_icon = "mdi:history"
    _attr_translation_key = "last_request_tokens"

    def __init__(self, entry: DeepSeekConfigEntry) -> None:
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_last_request_tokens"
        self._attr_suggested_object_id = "last_request_tokens"
        self._attr_device_info = usage_device_info(entry)
        self._attr_native_value = 0

    def set_usage(
        self, usage: CompletionUsage, *, source: str, request_count: int
    ) -> None:
        total = usage.total_tokens or usage.prompt_tokens + usage.completion_tokens
        self._attr_native_value = total
        self._attr_extra_state_attributes = {
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
            "reasoning_tokens": usage.reasoning_tokens,
            "cache_hit_tokens": usage.cache_hit_tokens,
            "cache_miss_tokens": usage.cache_miss_tokens,
            "cache_hit_rate": usage.cache_hit_rate,
            "source": source,
            "request_count": request_count,
        }
        _write_state_if_added(self)

    def reset_to_zero(self) -> None:
        self._attr_native_value = 0
        self._attr_extra_state_attributes = {}
        _write_state_if_added(self)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: DeepSeekConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up token usage sensors."""
    runtime = entry.runtime_data
    tracker: UsageTracker = runtime.usage

    prompt = DeepSeekUsageCounterSensor(
        entry,
        "prompt_tokens",
        "prompt_tokens",
        unit="tokens",
        icon="mdi:counter",
    )
    completion = DeepSeekUsageCounterSensor(
        entry,
        "completion_tokens",
        "completion_tokens",
        unit="tokens",
        icon="mdi:counter",
    )
    total = DeepSeekUsageCounterSensor(
        entry,
        "total_tokens",
        "total_tokens",
        unit="tokens",
        icon="mdi:counter",
    )
    reasoning = DeepSeekUsageCounterSensor(
        entry,
        "reasoning_tokens",
        "reasoning_tokens",
        unit="tokens",
        icon="mdi:brain",
    )
    cache_hit = DeepSeekUsageCounterSensor(
        entry,
        "cache_hit_tokens",
        "cache_hit_tokens",
        unit="tokens",
        icon="mdi:cached",
    )
    api_requests = DeepSeekUsageCounterSensor(
        entry,
        "api_requests",
        "api_requests",
        unit="requests",
        icon="mdi:api",
    )
    last_request = DeepSeekLastRequestSensor(entry)
    last_request_prompt = DeepSeekSnapshotSensor(
        entry, "last_request_prompt_tokens", "last_request_prompt_tokens"
    )
    last_request_completion = DeepSeekSnapshotSensor(
        entry, "last_request_completion_tokens", "last_request_completion_tokens"
    )

    tracker.bind_sensors(
        prompt=prompt,
        completion=completion,
        total=total,
        reasoning=reasoning,
        cache_hit=cache_hit,
        api_requests=api_requests,
        last_request=last_request,
        last_request_prompt=last_request_prompt,
        last_request_completion=last_request_completion,
    )

    async_add_entities(
        [
            prompt,
            completion,
            total,
            reasoning,
            cache_hit,
            api_requests,
            last_request,
            last_request_prompt,
            last_request_completion,
        ]
    )
